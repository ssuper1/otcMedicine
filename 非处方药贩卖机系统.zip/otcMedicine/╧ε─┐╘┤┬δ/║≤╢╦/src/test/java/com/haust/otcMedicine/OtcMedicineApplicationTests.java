package com.haust.otcMedicine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OtcMedicineApplicationTests {

    @Test
    void contextLoads() {
    }

}
