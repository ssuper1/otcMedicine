package com.haust.otcMedicine.service;
import com.haust.otcMedicine.entity.VendingMachineShelf;
import com.baomidou.mybatisplus.extension.service.IService;
import java.util.List;


public interface VendingMachineShelfService extends IService<VendingMachineShelf>{
}