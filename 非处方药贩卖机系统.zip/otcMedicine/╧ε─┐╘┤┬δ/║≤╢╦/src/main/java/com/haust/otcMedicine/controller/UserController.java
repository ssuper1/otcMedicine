package com.haust.otcMedicine.controller;

import com.haust.otcMedicine.entity.Admin;
import com.haust.otcMedicine.entity.User;
import com.haust.otcMedicine.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@CrossOrigin
@RestController
@RequestMapping("/api/auth")
public class UserController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        // 调用loginService的login方法进行验证
        User loggedInUser = loginService.login(user.getPhone(), user.getPassword());
        if (loggedInUser != null) {
            // 登录成功，返回用户信息和状态码200
            return ResponseEntity.ok(loggedInUser);
        } else {
            // 登录失败，返回状态码401并附带错误信息
            return ResponseEntity.status(401).body("用户名或密码错误");        }
    }
    @PostMapping
    public void addUser(@RequestBody User user) {
        loginService.save(user);
    }
}