package com.haust.otcMedicine.entity;

import lombok.Data;
import lombok.experimental.Accessors;

@Data
@Accessors(chain = true)
public class VendingMachineShelf {
    private Integer id;
    private Integer medicineId;
    private Integer capacity;
    private Integer remainCapacity;
}