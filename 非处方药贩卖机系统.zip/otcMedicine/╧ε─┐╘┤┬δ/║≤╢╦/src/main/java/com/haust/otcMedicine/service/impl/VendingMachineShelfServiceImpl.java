package com.haust.otcMedicine.service.impl;

import com.haust.otcMedicine.entity.VendingMachineShelf;
import com.haust.otcMedicine.mapper.VendingMachineShelfMapper;
import com.haust.otcMedicine.service.VendingMachineShelfService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

@Service
public class VendingMachineShelfServiceImpl extends ServiceImpl<VendingMachineShelfMapper, VendingMachineShelf> implements VendingMachineShelfService {
}