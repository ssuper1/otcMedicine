package com.haust.otcMedicine.controller;

import com.haust.otcMedicine.entity.VendingMachineShelf;
import com.haust.otcMedicine.service.VendingMachineShelfService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/api/vendingMachineShelves")
public class VendingMachineShelfController {

    @Autowired
    private VendingMachineShelfService vendingMachineShelfService;

    @GetMapping
    public List<VendingMachineShelf> getAllShelves() {
        return vendingMachineShelfService.list();
    }

    @GetMapping("/{id}")
    public VendingMachineShelf getShelfById(@PathVariable Integer id) {
        return vendingMachineShelfService.getById(id);
    }

    @PostMapping
    public void addShelf(@RequestBody VendingMachineShelf shelf) {
        vendingMachineShelfService.save(shelf);
    }

    @PutMapping("/{id}")
    public void updateShelf(@PathVariable Integer id, @RequestBody VendingMachineShelf shelf) {
        shelf.setId(id);
        vendingMachineShelfService.updateById(shelf);
    }

    @DeleteMapping("/{id}")
    public void deleteShelf(@PathVariable Integer id) {
        vendingMachineShelfService.removeById(id);
    }
}