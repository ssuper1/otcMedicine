package com.haust.otcMedicine.service.impl;

import com.haust.otcMedicine.entity.User;
import com.haust.otcMedicine.mapper.UserMapper;
import com.haust.otcMedicine.service.LoginService;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoginServiceImpl extends ServiceImpl<UserMapper, User> implements LoginService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public User login(String phone, String password) {
        // 使用手机号查询用户信息
        User user = userMapper.selectOne(new QueryWrapper<User>().eq("phone", phone));
        // 直接比较数据库中的密码和用户输入的原始密码
        if (user != null && password.equals(user.getPassword())) {
            // 账号密码匹配，返回用户信息
            return user;
        }
        // 账号不存在或密码不匹配，返回null
        return null;
    }
}