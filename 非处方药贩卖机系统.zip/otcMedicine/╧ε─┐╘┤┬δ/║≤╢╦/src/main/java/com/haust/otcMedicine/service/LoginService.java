package com.haust.otcMedicine.service;

import com.haust.otcMedicine.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;

public interface LoginService extends IService<User> {
    User login(String phone, String password);
}