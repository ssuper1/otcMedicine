package com.haust.otcMedicine.mapper;

import com.haust.otcMedicine.entity.Medicine;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface MedicineMapper extends BaseMapper<Medicine> {
    // MyBatis Plus 自动实现

}