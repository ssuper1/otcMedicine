package com.haust.otcMedicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.haust.otcMedicine.entity.VendingMachineShelf;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface VendingMachineShelfMapper extends BaseMapper<VendingMachineShelf> {
    // 可以添加一些自定义的方法，如果需要的话
}