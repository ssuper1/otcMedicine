package com.haust.otcMedicine.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.haust.otcMedicine.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    // 如果有特殊的数据库操作可以在这里添加
}