package com.haust.otcMedicine.controller;

import com.haust.otcMedicine.entity.Medicine;
import com.haust.otcMedicine.service.MedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin
@RestController
@RequestMapping("/api/medicines")
public class MedicineController {

    @Autowired
    private MedicineService medicineService;

    @GetMapping
    public List<Medicine> getAllMedicines() {
        return medicineService.list();
    }

    @GetMapping("/{id}")
    public Medicine getMedicineById(@PathVariable Integer id) {
        return medicineService.getById(id);
    }


    @GetMapping("/search")
    public ResponseEntity<List<Medicine>> searchByNameOrDescription(
            @RequestParam(value = "name", required = false) String name,
            //将Web请求中的参数映射到控制器方法的参数上
            @RequestParam(value = "description", required = false) String description) {

        List<Medicine> medicines = medicineService.searchByNameOrDescription(name, description);
        return ResponseEntity.ok(medicines); // 返回 200 OK 和查询结果
    }


    @PostMapping
    public void addMedicine(@RequestBody Medicine medicine) {
        medicineService.save(medicine);
    }

    @PutMapping("/{id}")
    public void updateMedicine(@PathVariable Integer id,@RequestBody Medicine medicine) {
        medicine.setId(id);/*这个响应体没传id，但url上有id，
       调用 Medicine 类的 medicine的 setId 方法，并将变量 id 的值赋给 medicine 实体的 id 属性
        */
        medicineService.updateById(medicine);
    }

    @DeleteMapping("/{id}")
    public void deleteMedicine(@PathVariable Integer id) {
        medicineService.removeById(id);
    }
}