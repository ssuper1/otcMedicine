package com.haust.otcMedicine.service;

import com.haust.otcMedicine.entity.Medicine;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

public interface MedicineService extends IService<Medicine> {
    // 可以添加自定义方法
    List<Medicine> searchByNameOrDescription(String name, String description);
  }