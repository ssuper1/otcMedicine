package com.haust.otcMedicine.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.haust.otcMedicine.entity.Medicine;
import com.haust.otcMedicine.mapper.MedicineMapper;
import com.haust.otcMedicine.service.MedicineService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MedicineServiceImpl extends ServiceImpl<MedicineMapper, Medicine> implements MedicineService {
    // 实现自定义方法
    @Autowired
    private MedicineMapper medicineMapper;

    // 自定义的模糊查询方法
    public List<Medicine> searchByNameOrDescription(String name, String description) {
        QueryWrapper<Medicine> queryWrapper = new QueryWrapper<>();
        //包含很多查询条件的类
        if (StringUtils.isNotBlank(name)) {
            //不为 null 、不为空字符串且不包含仅由空格组成的字符串
            queryWrapper.like("name", name);
        }
        if (StringUtils.isNotBlank(description)) {
            queryWrapper.like("description", description);
        }
        return medicineMapper.selectList(queryWrapper);
    }
}