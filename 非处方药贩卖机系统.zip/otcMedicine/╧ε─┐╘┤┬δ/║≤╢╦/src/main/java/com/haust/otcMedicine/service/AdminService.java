package com.haust.otcMedicine.service;

import com.haust.otcMedicine.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

public interface AdminService extends IService<Admin> {
    Admin login(String account, String password);
}