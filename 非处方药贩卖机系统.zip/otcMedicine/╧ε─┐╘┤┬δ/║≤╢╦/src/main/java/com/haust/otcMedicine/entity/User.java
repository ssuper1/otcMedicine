package com.haust.otcMedicine.entity;

import lombok.Data;

@Data
public class User {
    private Integer id;
    private String password;
    private String name;
    private String gender;
    private String phone;
    private String address;
}