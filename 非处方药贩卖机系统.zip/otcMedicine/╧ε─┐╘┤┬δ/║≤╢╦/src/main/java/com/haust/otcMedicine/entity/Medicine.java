package com.haust.otcMedicine.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import lombok.experimental.Accessors;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Accessors(chain = true)
public class Medicine {
    private Integer id;
    private String name;
    private int kinds;
    private BigDecimal price;
    private String photoUrl;
    //把 2022-12-31T16:00:00.000+00:00 规范为 2022-12-31
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date productionDate;
    @JsonFormat(shape=JsonFormat.Shape.STRING,pattern="yyyy-MM-dd",timezone="GMT+8")
    private Date expirationDate;
    private String description;
    // 省略其他字段和getter/setter方法
}