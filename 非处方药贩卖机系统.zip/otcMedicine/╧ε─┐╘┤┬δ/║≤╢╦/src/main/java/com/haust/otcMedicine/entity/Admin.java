package com.haust.otcMedicine.entity;

import lombok.Data;

@Data
public class Admin {
    private Integer id;
    private String account;
    private String password;
}