package com.haust.otcMedicine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OtcMedicineApplication {

    public static void main(String[] args) {
        SpringApplication.run(OtcMedicineApplication.class, args);
    }

}