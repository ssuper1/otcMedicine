<template>
    <div>
       <!-- 显示选中服装详情的对话框 -->
       <el-dialog v-model="detailDialogVisible" title="账号详情" width="30%">
        <div v-if="selectedAccount">
          <el-form label-width="120px">
            <el-form-item label="账号ID">
              <span>{{ selectedAccount.id }}</span>
            </el-form-item>
            <el-form-item label="用户名">
              <span>{{ selectedAccount.username }}</span>
            </el-form-item>
            <!-- 其他属性 -->
            <el-form-item label="邮箱">
              <span>{{ selectedAccount.email }}</span>
            </el-form-item>
            <el-form-item label="注册时间">
              <span>{{ selectedAccount.createdAt }}</span>
            </el-form-item>
            <el-form-item label="更新时间">
              <span>{{ selectedAccount.updatedAt }}</span>
            </el-form-item>
            <el-form-item label="帐号状态">
              <span>{{ selectedAccount.status }}</span>
            </el-form-item>
          </el-form>
        </div>
        <el-button type="primary" @click="detailDialogVisible = false">关闭</el-button>
      </el-dialog>
      <h2>账号列表</h2>
      <!-- 使用 el-table 组件来展示数据 -->
      <el-input v-model="searchId" placeholder="请输入账号ID" class="input-with-select">
        <template v-slot:append>
          <el-button icon="el-icon-search" @click="fetchAccountById">搜索</el-button>
        </template>
      </el-input>
      <el-table :data="pagedAccounts" style="width: 100%">
        <el-table-column prop="id" label="账号ID" width="180"></el-table-column>
        <el-table-column prop="username" label="用户名" width="180"></el-table-column>
        <el-table-column prop="email" label="邮箱"></el-table-column>
        <el-table-column prop="createdAt" label="注册时间"></el-table-column>
        <el-table-column prop="updatedAt" label="更新时间" width="180"></el-table-column>
        <el-table-column prop="status" label="帐号状态"></el-table-column>
        <el-table-column
          fixed="right"
          label="操作"
          width="200"
        >
          <template #default="{ row }">
            <el-button type="text" size="small" @click="openChangeDialog(row)">更新</el-button>
            <el-button type="text" size="small" @click="openDeleteDialog(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
  <el-pagination
  :current-page="currentPage"
  :page-size="pageSize"
  :total="accountList.length"
  @size-change="handleSizeChange"
  @current-change="handleCurrentChange"
  layout="total, sizes, prev, pager, next, jumper"
  style="margin-top: 15px"></el-pagination>
    
     <!-- 更新对话框 -->
     <el-dialog v-model="editDialogVisible" @close="editDialogVisible = false" title="更新账号信息">
      <el-form :model="editForm" label-width="120px" ref="editFormRef">
          <el-form-item label="账号ID">
            <el-input v-model="editForm.id"></el-input>
          </el-form-item>
          <el-form-item label="用户名">
            <el-input v-model="editForm.username"></el-input>
          </el-form-item>
          <el-form-item label="邮箱">
            <el-input v-model="editForm.email"></el-input>
          </el-form-item>
          <el-form-item label="帐号状态">
            <el-input-number v-model="editForm.status"></el-input-number>
          </el-form-item>
        </el-form>
        <el-button type="primary" @click="updateAccount">保存</el-button>
      </el-dialog>
  <!-- 删除对话框 -->
  <el-dialog v-model="deleteDialogVisible" @close="deleteDialogVisible = false" title="删除账号">
        <span>确认删除该账号吗？</span>
        <template #footer>
          <span class="dialog-footer">
            <el-button @click="deleteDialogVisible = false">取消</el-button>
            <el-button type="danger" @click="confirmDelete">确认删除</el-button>
          </span>
        </template>
      </el-dialog>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted, computed } from 'vue';
  import axios from '../axios';
  import { ElButton, ElTable, ElTableColumn, ElDialog, ElForm, ElFormItem, ElInput, ElInputNumber } from 'element-plus';

      const accountList = ref([]);
      const editDialogVisible = ref(false);
      const deleteDialogVisible = ref(false);
      const currentPage = ref(1);
      const pageSize = ref(10);
      const editForm = ref({
        id: '',
        username: '',
        email: '',
        status:''
      });
      const currentAccount = ref(null);
      const pagedAccounts = computed(() => {
  const start = (currentPage.value - 1) * pageSize.value;
  return accountList.value.slice(start, start + pageSize.value);
});
      
    
      const searchId = ref('');// 用户输入的服装ID
      // 用于存储选中的服装详情
      const selectedAccount = ref(null);
      // 控制详情对话框的显示
      const detailDialogVisible = ref(false);
      const filteredByIdAccountList = computed(() => {
      return accountList.value.filter(item => item.id.toString() === searchId.value);
    });
	
  const fetchAccountById = async () => {  
        try {
          // 发送 GET 请求到后端API查询服装信息
          const response = await axios.get(`http://localhost:8085/api/account/${searchId.value}`);
          
          // 检查返回的状态码，如果成功则处理数据
          if (response.status === 200 && response.data) {
            const accountItem = response.data;
            selectedAccount.value = accountItem;
            detailDialogVisible.value = true; // 显示详情对话框
          } else {
            alert('未找到该账号ID');
          }
        } catch (error) {
          // 网络请求异常处理
          console.error('Error fetching clothing by ID:', error);
          alert('查询时发生错误');
        } finally {
          searchId.value = ''; // 清空输入的ID
        }
      };
      const fetchAccountList = async () => {
        const response = await axios.get('/account');
        accountList.value = response.data;
      };
      onMounted(fetchAccountList);
  
      
        // 打开编辑对话框
      const openChangeDialog = (row) => {
        editForm.value = { ...row };
        editDialogVisible.value = true;
      };
      // 确认更新
      const updateAccount = async () => {
    try {
      // 发送 PUT 请求更新账号信息
      await axios.put(`http://localhost:8085/api/account/${editForm.value.id}`, editForm.value);
  
  
      // 假设请求成功，执行以下操作：
      // 重新获取最新的服装列表
      fetchAccountList();
      // 关闭编辑对话框
      editDialogVisible.value = false;
      // 重置编辑表单
      resetEditForm();
    } catch (error) {
      // 打印错误信息，或者给用户一个错误提示
      console.error('Error updating clothing:', error);
      // 可以在这里添加错误处理逻辑，如提示用户更新失败
    }
  };
  
       // 打开删除对话框
       const openDeleteDialog = (row) => {
        currentAccount.value = row;
        deleteDialogVisible.value = true;
      };
  
      // 确认删除
      const confirmDelete = async () => {
        // 删除逻辑
        try {
      await axios.delete(`http://localhost:8085/api/account/${currentAccount.value.id}`);
      // 删除成功，重新获取列表并关闭对话框
      fetchAccountList();
      deleteDialogVisible.value = false;
    } catch (error) {
      console.error('Error deleting account:', error);
      // 可以在这里添加错误处理逻辑，如提示用户删除失败
    }
        deleteDialogVisible.value = false;
      };
  
     
  
      // 重置编辑表单
      const resetEditForm = () => {
        // 重置 editForm 的每个属性为初始值或空字符串
        editForm.value = {
          id: '',
        username: '',
        email: ''
        };
      };
      const handleSizeChange = (newSize) => {
  pageSize.value = newSize; // 使用 .value 来直接操作响应式状态
};

const handleCurrentChange = (newPage) => {
  currentPage.value = newPage; // 使用 .value 来直接操作响应式状态
};

      
   
  </script>

