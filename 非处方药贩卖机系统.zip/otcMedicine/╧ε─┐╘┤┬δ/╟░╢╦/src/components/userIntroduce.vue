<template>	
 <userNavBar/>
	<!-- ====================================展示表格========================= -->  
	<div class="all">
	<div class="el-container">
		<el-table :data="pagedAccounts" class="table">
		<el-table-column prop="id" label="ID" width="80"></el-table-column>
		<el-table-column prop="name" label="名称" width="120"></el-table-column>
		<el-table-column prop="price" label="价格"></el-table-column>
		<el-table-column prop="photoUrl" label="图片" width="180">
		  <template #default="{ row }">
			<!-- 使用 v-html 来生成 <img> 标签 -->
			<div v-html="createImageTag(row.photoUrl)"></div>
		  </template>
		</el-table-column>
		<el-table-column prop="productionDate" label="生产日期" ></el-table-column>
		<el-table-column prop="expirationDate" label="过期时间" ></el-table-column>
		<el-table-column prop="description" label="详情"></el-table-column> 
		</el-table>
  </div>
	<!-- ===================查询================================-->
	<div class="search-box" >
	  <el-input
		v-model="searchParams.queryString"
		placeholder="输入ID或药品名称/详情"
		class="search-input"
	  ></el-input>
	<!-- 独立的确认按钮 -->
	<el-button
		type="success"			
		@click="performSearch"
		style="margin-left: 10px;"
	>查询</el-button>
	</div>
</div>		
	<!-- “重置”按钮，仅在 canReset 为 true 时显示 -->
	<el-button
	  type="warning"
	  v-if="canReset"
	  @click="resetSearch"
	  style="margin-left: 10px;">
	  返回
	</el-button>
	
	 <el-pagination style="margin: 5px;display: flex; justify-content: center;"
		background layout="prev, pager, next" 
		  :current-page="currentPage"
		  :page-size="pageSize"
		  :total="medicines.length"
		  @current-change="handleCurrentChange"></el-pagination><!-- -->
</template>


<script setup>
import { ref, onMounted,computed } from 'vue';
import { apiClient, apiVendingMachineShelves } from '../api.js';
//
import { ElForm, ElInput,ElButton,ElDialog, ElMessage } from 'element-plus';
import userNavBar from './userNavBar.vue'
  
	//=============================
	 const searchParams = ref({ queryString: '' }); // 确保 searchParams 是一个 ref
	//=============================
 // 是否可以重置搜索，初始为 false
	    const canReset = ref(false);	
	//	
// ===================展示================================-->	
	  
		  //=============================
    const medicines = ref([]);
	const createImageTag = (photoUrl) => {
		return `<img src="${photoUrl}" alt="药品图片" style="width: 100px; height: auto;" />`;
		};
    onMounted(async () => {
      try {
        // 确保请求的端口号是8085
        const response = await apiClient.get('/');
        medicines.value = response.data;
      } catch (error) {
        console.error('Error fetching medicines:', error);
      }
    });
//-- ===================分页===============================-->		
  const currentPage = ref(1);
   const pageSize = ref(4);
	const pagedAccounts = computed(() => {
	  const start = (currentPage.value - 1) * pageSize.value;
	  return medicines.value.slice(start, start + pageSize.value);
	});
	
	const handleCurrentChange = (newPage) => {
	  currentPage.value = newPage; // 使用 .value 来直接操作响应式状态
	};

//-- ===================查询================================-->	
  const performSearch = async () => {
        try {
          const queryString = searchParams.value.queryString.trim();
          if (queryString) {
			// 标记可以重置，因为用户已经输入了查询字符串
			canReset.value = true;
			const isNumeric = String(searchParams.value.queryString).replace(/\D/g, '');
			//let response;
			if (isNumeric){
				// 清除之前的查询结果
				medicines.value = [];
				const response = await apiClient.get(`/${encodeURIComponent(queryString)}`);
				 /*将 queryString 中的任何特殊字符转换成安全的编码形式,Hello World!"，返回 "Hello%20World%21"
				有的浏览器碰见空格什么的就报错了
				*/
				// 检查返回的数据是否存在
				const medicine = response.data;
				if (medicine) {
				  // 如果返回了药品数据，则将其设置为当前显示的药品列表
				  medicines.value.push(medicine);
				  ElMessage.success('查询成功！');						
				}	
			}
			// 发送请求到后端进行模糊查询，分别查询名称和描述
		   else{
            const [nameResponse, descriptionResponse] = await Promise.all([
              apiClient.get('/search', { params: { name: queryString } }),
              apiClient.get('/search', { params: { description: queryString } })
            ]);
  
            // 合并两个请求的结果，并去除重复项
            const allMedicines  = [...new Set([...nameResponse.data, ...descriptionResponse.data])];

            // 按照 ID 排序
            const sortedMedicines = allMedicines.sort((a, b) => a.id - b.id);
  
            // 更新药品列表
            medicines.value = sortedMedicines;
            ElMessage.success('查询成功！');
			}
          } else {
            ElMessage.error('请输入药品名称或描述进行搜索！');		 	 
          }
        } catch (error) {
          ElMessage.error('查询失败，请稍后再试！');
          console.error('Error searching medicines:', error);
        }
      };
	// 刷新表格数据
	const fetchData = async () => {
	  try {
	    const response = await apiClient.get('/');
	    medicines.value = response.data;
	  } catch (error) {
	    console.error('Error fetching medicines:', error);
	  }
	};
	 // 重置搜索条件的方法
	const resetSearch = async () => {
		// 重新加载货架数据以刷新显示
		await fetchData();
		canReset.value = false;
	 };
    
</script>



<style scoped>
.all{
	display: flex;
}

.search-box { 
	display: flex;
 position: fixed;
  top: 10px;
  right: 20px;
  z-index: 1;
}
</style>