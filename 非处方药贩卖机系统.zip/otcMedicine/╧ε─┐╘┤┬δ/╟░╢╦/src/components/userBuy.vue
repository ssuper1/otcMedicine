<template>
	<userNavBar/>
	<div class="all">
		<!-- ===================展示================================-->	
		<div class="el-container" >
			<el-table :data="pagedAccounts" class="table">
			  <el-table-column prop="id" label="货架编号" width="80"></el-table-column>
			  <el-table-column prop="medicineId" label="药品ID" width="80"></el-table-column>
			  <el-table-column prop="capacity" label="容量" ></el-table-column>
			  <el-table-column prop="remainCapacity" label="剩余容量" ></el-table-column>
			  <!-- 展示药品名称 -->
			  <el-table-column prop="medicine.name" label="药品名称" ></el-table-column>
			  <!-- 展示药品图片 -->
			  <el-table-column label="药品图片" width="200">
				<template #default="{ row }">
				  <img v-if="row.medicine.photoUrl" :src="row.medicine.photoUrl" alt="药品图片" style="width: 50px; height: auto;">
				  <span v-else>暂无图片</span>
				</template>
			  </el-table-column>    
			  <!-- 添加操作列 -->
			  <el-table-column label="操作" width="100">
				<template #default="{ row }">
				 <!-- 弹出确认窗口的按钮 -->
					<el-button type="primary"
					size="small" @click="showBuyDialog(row)">购买</el-button>
				</template>
			  </el-table-column>		    
			</el-table>		
		</div>	

	<!-- ===================查询================================-->
	    <div class="search-box" >
	      <!-- 添加搜索框 -->
	         <el-input
	           v-model="searchParams.queryString"
	           placeholder="输入货架编号或药品名称"	
				class="search-input"   
	         ></el-input>
			<!-- 独立的确认按钮 -->
			<el-button type="success" @click="searchShelves" 
			style="margin-left: 10px;">查询</el-button>	 	   
		</div>
	</div>			  
<!-- 添加购买确认对话框 -->
	   <el-dialog
	     v-model="buyDialogVisible"
	     title="确认购买"
	     width="30%">
	     <span>确定购买此药品吗?</span>
	     <template #footer>
	       <span class="dialog-footer">
	         <el-button @click="buyDialogVisible = false">取 消</el-button>
	         <el-button type="primary" @click="buyMedicine">确 定</el-button>
	       </span>
	     </template>
	   </el-dialog>
	   
	
	<!-- “重置”按钮，仅在 canReset 为 true 时显示 -->
	<el-button
	  type="warning"
	  v-if="canReset"
	  @click="resetSearch"
	  style="margin-left: 10px;">
	  返回
	</el-button>	
	
	 <el-pagination style="margin: 5px;display: flex; justify-content: center;"
 		background layout="prev, pager, next,jumper" 
 		  :current-page="currentPage"
 		  :page-size="pageSize"
 		  :total="filteredShelves.length"
 		  @current-change="handleCurrentChange"></el-pagination>	
</template>

<script setup>
import { ref, onMounted,computed } from 'vue';
import { apiClient, apiVendingMachineShelves } from '../api.js'; // 修改导入语句
import {ElTable,ElTableColumn,ElDialog,ElForm,ElFormItem,
  ElInput,ElButton,ElMessage,ElTag,ElSkeletonItem, ElSkeleton} from 'element-plus';	
import { useRouter } from 'vue-router';
import userNavBar from './userNavBar.vue'
		//=============================
		const searchParams = ref({ queryString: '' }); // 确保 searchParams 是一个 ref
//<!-- ===================展示================================--> 
		const shelves = ref([]);	
		const filteredShelves = ref([]);
	   // 是否可以重置搜索，初始为 false
	    const canReset = ref(false);	
		const router = useRouter(); // 获取路由实例
	 const buyDialogVisible = ref(false); // 控制购买对话框的显示
	 //货架数据
	 const selectedShelf = ref({});
	 
    onMounted(async () => {
    	await fetchShelvesWithMedicineInfo();
    });
 // 异步获取货架信息及其对应的药品信息
 const fetchShelvesWithMedicineInfo = async () => {
      try {
        const shelvesResponse = await apiVendingMachineShelves.get('');
        const shelfData = shelvesResponse.data;
        const medicinePromises = shelfData.map(async (shelf) => {
          const medicineResponse = await apiClient.get(`/${shelf.medicineId}`);
          return { ...shelf, medicine: medicineResponse.data };
        });
        const shelvesWithMedicine = await Promise.all(medicinePromises);
        shelves.value = shelvesWithMedicine; // 存储原始货架数据
        filteredShelves.value = shelvesWithMedicine; // 初始化过滤数据
      } catch (error) {
        console.error('Error fetching shelves or medicines:', error);
        ElMessage.error('获取货架或药品信息失败');
      }
    };
	//-- ===================分页===============================-->
	 const currentPage = ref(1);
	   const pageSize = ref(6);
		const pagedAccounts = computed(() => {
		  const start = (currentPage.value - 1) * pageSize.value;
		  return filteredShelves.value.slice(start, start + pageSize.value);
		});	
		const handleCurrentChange = (newPage) => {
		  currentPage.value = newPage; // 使用 .value 来直接操作响应式状态
		};	
//-- ===================查询================================-->
	 // 搜索货架的方法
	 const searchShelves = () => {
		 // 检查查询字符串是否为空
		  if (searchParams.value.queryString.trim() === '') {
		    ElMessage.error('请输入查询数据');
		    return;
		  }
		  // 标记可以重置，因为用户已经输入了查询字符串
		  canReset.value = true;
		 
	   // 检查查询字符串是否为纯数字
	   const queryId = String(searchParams.value.queryString).replace(/\D/g, '');
	   const isNumeric = queryId !== '' ;
	   if (isNumeric) {
	     // 如果查询字符串是纯数字，则执行精准查询
	     filteredShelves.value = shelves.value.filter(shelf => {
	       const shelfId = shelf.id.toString();
	       return shelfId === queryId;
	     });
	   } else {
	     // 如果查询字符串包含非数字字符，则执行名称的包含查询
	     filteredShelves.value = shelves.value.filter(shelf => {
	       return shelf.medicine.name.toLowerCase().includes(searchParams.value.queryString.toLowerCase());
	     });
	   }
	 };
//-- ===================购买================================-->
 // 显示购买对话框的方法
    const showBuyDialog = (row) => {
		// 检查剩余容量是否为0
		  if (row.remainCapacity <= 0) {
		    ElMessage.error('容量不足，无法购买');
		    return;
		  }	   
		 buyDialogVisible.value = true;
      selectedShelf.value = row;    
    };

    // 用户确认购买后调用的方法
    const buyMedicine = async () => {
      try {
        // 确认所选货架不为空
        if (!selectedShelf.value) {
          ElMessage.error('请选择要购买的货架');
          return;
        }
		// 准备更新的数据，这里我们只更新 remainCapacity 字段
		const updateData = {
		    remainCapacity: selectedShelf.value.remainCapacity - 1
		};
	
        // 注意这里的请求方法是 put，且我们只发送了需要更新的字段
		await apiVendingMachineShelves.put(`/${selectedShelf.value.id}`, updateData);// 显示购买成功的提示信息
        ElMessage.success('购买成功！');
	 // 重新加载货架数据以刷新显示
	    await fetchShelvesWithMedicineInfo();
	
      } catch (error) {
        // 错误处理
        console.error('购买失败:', error);
        ElMessage.error('购买失败，请重试！');
      } finally {
        // 隐藏对话框
        buyDialogVisible.value = false;
        // 清空所选货架数据，防止状态残留
        selectedShelf.value = null;
      }
    };
//

 // 重置搜索条件的方法
const resetSearch = async () => {
	// 重新加载货架数据以刷新显示
	await fetchShelvesWithMedicineInfo();
	canReset.value = false;
 };


		
</script>

<style scoped>
.all{
	display: flex;
}

.search-box { 
	display: flex;
 position: fixed;
  top: 10px;
  right: 20px;
  z-index: 1;
}

</style>