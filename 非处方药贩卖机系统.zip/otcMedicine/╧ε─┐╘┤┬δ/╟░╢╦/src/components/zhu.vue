<template>
  <div class="clothing-bar">
    <div ref="barChart" style="width: 100%; height: 400px;"></div>
  </div>
</template>

<script>
import * as echarts from 'echarts';

export default {
  name: 'ClothinBar',
  data() {
    return {
      chartInstance: null,
      categories: {
        cold: 0,
        wei: 0,
        tu: 0
      }
    };
  },
  mounted() {
    this.fetchData();
    this.initChart();
  },
  methods: {
    fetchData() {
      fetch('http://localhost:8085/api/medicines')
        .then(response => response.json())
        .then(data => {
          this.updateCategories(data);
        })
        .catch(error => console.error('Error fetching data: ', error));
    },
    updateCategories(data) {
      data.forEach(item => {
        switch (item.kinds) {
          case 1:
            this.categories.cold += 1;
            break;
          case 2:
            this.categories.wei += 1;
            break;
          case 3:
            this.categories.tu += 1;
            break;
        }
      });
      this.updateChart();
    },
    initChart() {
      this.chartInstance = echarts.init(this.$refs.barChart);
      const option = {
        title: {
          text: '医药种类'
        },
        tooltip: {},
        legend: {
          data: ['Quantity']
        },
        xAxis: {
          data: ['感冒药', '肠胃药', '外敷']
        },
        yAxis: {},
        series: [{
          name: 'Quantity',
          type: 'bar',
          data: [0, 0, 0]
        }]
      };
      this.chartInstance.setOption(option);
    },
    updateChart() {
      this.chartInstance.setOption({
        series: [{
          data: [this.categories.cold, this.categories.wei, this.categories.tu]
        }]
      });
    }
  }
};
</script>

<style>
/* Add your styles here */
</style>