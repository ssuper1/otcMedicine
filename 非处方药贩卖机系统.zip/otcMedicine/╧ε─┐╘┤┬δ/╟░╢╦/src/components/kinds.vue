<template>
    <div class="clothing-pie">
      <div ref="pieChart" style="width: 100%; height: 400px;"></div>
    </div>
  </template>
  
  <script >
  import * as echarts from 'echarts';
  import adminNavBar from './adminNav.vue'
  
  export default {
    name: 'ClothinPie',
    data() {
      return {
        chartInstance: null,
        categories: {
          cold: 0,
          wei: 0,
          tu: 0
        }
      };
    },
    mounted() {
      this.fetchData();
      this.initChart();
    },
    methods: {
      fetchData() {
        fetch('http://localhost:8085/api/medicines')
          .then(response => response.json())
          .then(data => {
            this.updateCategories(data);
          })
          .catch(error => console.error('Error fetching data: ', error));
      },
      updateCategories(data) {
        data.forEach(item => {
          switch (item.kinds) {
            case 1:
              this.categories.cold += 1;
              break;
            case 2:
              this.categories.wei += 1;
              break;
            case 3:
              this.categories.tu += 1;
              break;
          }
        });
        this.updateChart();
      },
      initChart() {
        this.chartInstance = echarts.init(this.$refs.pieChart);
        const option = {
          title: {
            text: '                         药品分布图'
          },
          tooltip: {
            trigger: 'item'
          },
          legend: {
            orient: 'vertical',
            left: 'left'
          },
          series: [{
            name: 'Quantity',
            type: 'pie',
            radius: '50%',
            data: [
              { value: 0, name: 'Top' },
              { value: 0, name: 'Pants' },
              { value: 0, name: 'Shoes' }
            ],
            emphasis: {
              itemStyle: {
                shadowBlur: 10,
                shadowOffsetX: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          }]
        };
        this.chartInstance.setOption(option);
      },
      updateChart() {
        this.chartInstance.setOption({
          series: [{
            data: [
              { value: this.categories.cold, name: '感冒类' },
              { value: this.categories.wei, name: '肠胃类' },
              { value: this.categories.tu, name: '外敷类' }
            ]
          }]
        });
      }
    }
  };
  </script>
  
  <style>
  /* Add your styles here */
  </style>