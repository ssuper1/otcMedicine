<template>
<div class="all">
	<el-card class="box-card">	  
		<div slot="header" class="clearfix">
			<span class="login-title">Login</span> 
				<!-- 添加一个按钮用于跳转到管理员页面 -->
			<el-button  class="admin-login-button" 
				type="success" plain
			@click="goToMedicineManage">管理员登录</el-button>
		</div >
		<div class="login-input">
			<el-form :model="loginForm" label-width="80px">
			  <el-form-item label="手机号:">
				<el-input v-model="loginForm.phone"></el-input>
			  </el-form-item>
			  <el-form-item label="密码：">
				<el-input type="password" v-model="loginForm.password"></el-input>
			  </el-form-item>
			  <el-form-item>
				<el-button type="primary" @click="Login">登录</el-button>
				<el-button type="primary" @click="showAddDialog = true">注册</el-button>
			  </el-form-item>
			</el-form>
		</div>
	</el-card>
</div>	
<!-- 弹窗：增加/编辑信息 -->
		<el-dialog v-model="showAddDialog" title="注册" width="30%">
		  <el-form :model="itemForm"  >
			 <el-form-item label="电话" prop="phone">
			   <el-input v-model="itemForm.phone"></el-input>
			 </el-form-item> 
		    <el-form-item label="密码" prop="password">
		      <el-input v-model="itemForm.password"></el-input>
		    </el-form-item>
			
			  <el-form-item label="姓名" prop="name">
			    <el-input v-model="itemForm.name"></el-input>
			  </el-form-item>
			 
			 <el-form-item label="性别" prop="gender">
			   <el-input v-model="itemForm.gender"></el-input>
			 </el-form-item>

			  <el-form-item label="地址" prop="address">
			    <el-input v-model="itemForm.address"></el-input>
			  </el-form-item>
		  </el-form>
		  <template #footer>
		    <div class="dialog-footer">
		      <el-button @click="showAddDialog = false">取消</el-button>
		      <el-button type="primary" @click="submitForm">提交</el-button>
		    </div>
		  </template>
		</el-dialog>
</template>

<script setup>
import { ref } from 'vue';
import { ElForm, ElFormItem, ElInput, ElButton, ElCard, ElMessage } from 'element-plus';
import axios from 'axios';
import { useRouter } from 'vue-router';

    const loginForm = ref({
      phone: '',
      password: '',
    });/*对象类型 ,不是简单的数值*/
	const router = useRouter(); // 获取路由实例
   const Login = async () => {
     try {
       const response = await axios.post('http://localhost:8085/api/auth/login', loginForm.value);
         ElMessage.success('成功登录');

        // 登录成功后，跳转到用户页面
		router.push('/userBuy'); // 假设用户页面的路由路径是 
     } catch (error) {
       console.error('Login error details:', error);     
       ElMessage.error('密码错误');
     }
   };

 // 添加一个方法用于跳转到管理员页面
    const goToMedicineManage = () => {
      router.push('/adminLogin');
    };
	
const showAddDialog = ref(false);
const itemForm = ref({
id: null,
password: '' ,
name: '', 
 gender:'',
 phone:'',
 address:''
});
// 提交表单
const submitForm = async () => {
  try {
    const formData = itemForm.value;
    await axios.post('http://localhost:8085/api/auth', formData);
    ElMessage.success('操作成功！');
    showAddDialog.value = false;
    itemForm.value = {id: null,password: '' ,name: '', gender:'',phone:'',address:''};
    // 刷新表格数据
   
  } catch (error) {
    console.error('Error submitting form:', error);
    ElMessage.error('操作失败，请重试！');
  }
};   
</script>
<style scoped>
/* 将背景样式应用到页面的根元素上 */
.all{
	display: flex;
	height: 96vh;
	background-image: url('../assets/雪山.png');
	background-size: cover; /* 让背景图片铺满整个页面 */
	background-repeat: no-repeat; /* 防止背景图片重复显示 */
}
.box-card {
  width: 300px;
  margin: auto;
  justify-content: center;
  place-items: center;
}

.admin-login-button{	
	position: fixed; 
	left: 30px; 
	top: 30px;	
}
.login-title {
  font-size: 24px; /* 设置字体大小 */
  font-weight: bold; /* 设置字体为粗体 */
  color: #55aa00; /* 设置文本颜色 */
}
.login-input{
	margin-top: 10px;
}


</style>