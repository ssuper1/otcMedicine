<template>
	<el-menu
	:default-active="activeIndex" 
	class="el-menu-demo" 
	mode="horizontal" 
	@select="handleSelect">
	  <el-menu-item index="/medicineManage" >医药管理</el-menu-item>
	  <el-menu-item index="/vending-machine-shelves">货架管理</el-menu-item>
	  <el-menu-item index="/kinds">饼状图</el-menu-item>
	  <el-menu-item index="/zhu">柱状图</el-menu-item>	  
	   <el-menu-item index="/userbuy"><img src="../assets/img/arrow-return-left.svg" alt="Bootstrap" width="20" ></el-menu-item>
	</el-menu>
</template>

<script setup>
import { ref, onMounted, watch } from 'vue';
import { ElMenu, ElMenuItem } from 'element-plus';
import { useRouter, useRoute } from 'vue-router';

const router = useRouter();
const route = useRoute();
const activeIndex = ref(route.path); // 根据当前路由设置初始激活项

const handleSelect = (index) => {
  router.push(index);
  activeIndex.value = index; // 点击菜单项时更新激活项
};
</script>
<style scoped>
	.el-menu-demo{
		background-color: #e0f1ff; /* 根据需要调整背景色 */
	}
</style>