<template>
	<adminNavBar/>
 <!-- ===================添加================================-->
	<div class="top">
		<div class="left">
		<!-- 添加按钮 -->
			<el-button type="success" @click="showAddDialog = true">增加信息</el-button>
		</div>
		<!-- 搜索框 -->
		<div class="search-box">
			<el-input
				v-model="searchParams.queryString"
				placeholder="输入货架或药品名称"
				class="search-input"
			></el-input>
			<el-button type="success" @click="searchShelves">查询</el-button>
		</div>
	</div>
	  <!--========================= 增加的弹窗 =========================-->
	  <el-dialog v-model="showAddDialog"  title="增加货架信息"
	    width="40%" @closed="resetForm">
	    <el-form :model="shelvesForm" label-width="100px">
	      <el-form-item label="货架编号" prop="id">
	        <el-input v-model="shelvesForm.id" ></el-input>
	      </el-form-item>
	      <el-form-item label="药品ID" prop="medicineId">
	        <el-input v-model="shelvesForm.medicineId"></el-input>
	      </el-form-item>
	      <el-form-item label="容量" prop="capacity">
	        <el-input type="number" v-model="shelvesForm.capacity" ></el-input>
	      </el-form-item>
	      <el-form-item label="剩余容量" prop="remainCapacity">
	        <el-input type="number" v-model="shelvesForm.remainCapacity" ></el-input>
	      </el-form-item>
	    <el-form-item>
	        <el-button type="primary" @click="submitForm">提交</el-button>
	        <el-button @click="showAddDialog = false">取消</el-button>
	     </el-form-item>
		</el-form>		   
	  </el-dialog>  	
	<div >
 <!-- ===================展示================================-->
    <el-table :data="pagedAccounts" style="width: 100%">
      <el-table-column prop="id" label="货架编号" width="80"></el-table-column>
      <el-table-column prop="medicineId" label="药品ID" width="80"></el-table-column>
	  	<el-table-column prop="medicine.kinds" label="种类" width="80"></el-table-column>
      <el-table-column prop="capacity" label="容量"></el-table-column>
      <el-table-column prop="remainCapacity" label="剩余容量"></el-table-column>
      <el-table-column prop="medicine.name" label="药品名称" width="120"></el-table-column>
      <!-- 展示药品图片 -->
      <el-table-column label="药品图片" width="180">
        <template #default="{ row }">
          <img v-if="row.medicine.photoUrl" :src="row.medicine.photoUrl" alt="药品图片" style="width: 50px; height: auto;">
          <span v-else>暂无图片</span>
        </template>
      </el-table-column>
      <!-- 添加操作列 -->
      <el-table-column label="操作" width="200">
        <template #default="{ row }">
          <el-button type="primary" size="small" @click="editShelf(row)">修改</el-button>
          <el-button type="danger" size="small" @click="deleteShelf(row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
<!-- ===================分页================================-->	
 <el-pagination style="margin: 5px;display: flex; justify-content: center;"
 		background layout="prev, pager, next,jumper" 
 		  :current-page="currentPage"
 		  :page-size="pageSize"
 		  :total="shelves.length"
 		  @current-change="handleCurrentChange"></el-pagination>
        <!-- ===================修改================================-->
    <!-- 编辑货架信息的对话框 -->
       <el-dialog
         v-model="editDialogVisible"
         title="编辑货架信息"
         width="40%">
         <el-form :model="currentShelf" label-width="100px">
           <el-form-item label="货架编号" prop="id">
             <el-input v-model="currentShelf.id" disabled></el-input>
           </el-form-item>
           <el-form-item label="药品ID" prop="medicineId">
             <el-input v-model="currentShelf.medicineId"></el-input>
           </el-form-item>
           <el-form-item label="容量" prop="capacity">
             <el-input type="number" v-model="currentShelf.capacity"></el-input>
           </el-form-item>
           <el-form-item label="剩余容量" prop="remainCapacity">
             <el-input type="number" v-model="currentShelf.remainCapacity"></el-input>
           </el-form-item>
           <!-- 添加其他表单项 -->
         </el-form>
         <template #footer>
           <div class="dialog-footer">
             <el-button @click="editDialogVisible = false">取消</el-button>
             <el-button type="primary" @click="submitUpdate">更新</el-button>
           </div>
         </template>
       </el-dialog>
		<!-- “重置”按钮，仅在 canReset 为 true 时显示 -->
		<el-button
		  type="warning"
		  v-if="canReset"
		  @click="resetSearch"
		  style="margin-left: 10px;">
		  返回
		</el-button>			
</div>
</template>



<script setup>
import { ref, onMounted,computed } from 'vue';
import adminNavBar from './adminNav.vue'
import { ElButton, ElInput, ElTable, ElTableColumn, ElDialog, ElForm, ElFormItem, ElMessage } from 'element-plus';
import { apiClient, apiVendingMachineShelves } from '../api.js'; // 修改导入语句
// import * as echarts from 'echarts';
    const shelves = ref([]);
	const orishelves = ref([]);

    const currentShelf = ref({});
    const editDialogVisible  = ref(false);
	//
    const medicineDialogVisible = ref(false);
    const currentMedicine = ref({});
	//
	const showAddDialog = ref(false);
	const shelvesForm = ref({});
	//=============================
	 const searchParams = ref({ queryString: '' }); // 确保 searchParams 是一个 ref
	   // 是否可以重置搜索，初始为 false
	    const canReset = ref(false);
//<!-- ===================展示================================-->
    onMounted(async () => {
    	await fetchShelvesWithMedicineInfo();
    });

// 异步获取货架信息及其对应的药品信息
	//async function fetchShelvesWithMedicineInfo(){
	const fetchShelvesWithMedicineInfo = async () => {
      try {
        const shelvesResponse = await apiVendingMachineShelves.get('/');
        const shelfData = shelvesResponse.data;
        const medicinePromises = shelfData.map(async (shelf) => {
			/*map：数组的高阶函数，遍历整个数组。并对表格中每一行都执行里面的操作*/
          const medicineResponse = await apiClient.get(`/${shelf.medicineId}`);
          return { ...shelf, medicine: medicineResponse.data };
		  /*添加一个新的 medicine 属性，其值为异步API调用返回的药品数据。*/
        });
        const shelvesWithMedicine = await Promise.all(medicinePromises);
        orishelves.value = shelvesWithMedicine; // 
        shelves.value = shelvesWithMedicine; // 初始化过滤数据
      } catch (error) {
        console.error('Error fetching shelves or medicines:', error);
        ElMessage.error('获取货架或药品信息失败');
      } 
    };
//-- ===================分页===============================-->		
 const currentPage = ref(1);
   const pageSize = ref(5);
	const pagedAccounts = computed(() => {
	  const start = (currentPage.value - 1) * pageSize.value;
	  return shelves.value.slice(start, start + pageSize.value);
	});	
	const handleCurrentChange = (newPage) => {
	  currentPage.value = newPage; // 使用 .value 来直接操作响应式状态
	};	
	
//<!-- ========================剩余容量不能大于容量==========================-->	
	const validateRemainCapacity = (Data) => {
	  const remainCapacity = Data.remainCapacity;
	  const capacity = Data.capacity;
	  if (remainCapacity > capacity) {
	    ElMessage.error('剩余容量不能大于容量！');
	    return false;
	  }
	  return true;
	};
	
	
	
//<!-- ========================增加===========================-->
 // 提交添加表单
    const submitForm = async () => {
      try {
        // 触发表单校验				
		const isValid = validateRemainCapacity(shelvesForm.value);
		if (!isValid) return;
        // 发起请求
        await apiVendingMachineShelves.post('/', shelvesForm.value);
        // 提交成功后的逻辑处理
        ElMessage.success('增加货架成功！');
        showAddDialog.value = false; // 关闭对话框
       fetchShelvesWithMedicineInfo();
      } catch (error) {
        console.error('Error adding shelf:', error);
        ElMessage.error('增加货架失败，请重试！');
      }
    };
//<!-- ===================删除================================-->		
    // 使用 apiVendingMachineShelves 来删除货架
    const deleteShelf = async (id) => {
      try {
        await apiVendingMachineShelves.delete(`/${id}`); // 修改为使用 apiVendingMachineShelves
        fetchShelvesWithMedicineInfo();
      } catch (error) {
        console.error('Error deleting shelf:', error);
      }
    };
//<!-- ===================修改================================-->
 // 编辑货架信息
	const editShelf = (shelf) => {		    
		editDialogVisible.value = true; // 显示编辑对话框
		 currentShelf.value = {...shelf}; // 设置当前货架信息
	};		
	// 提交更新
	const submitUpdate = async () => {
		try {
			// 触发表单校验
			//await shelfFormRef.value.validate();
			const isValid = validateRemainCapacity(currentShelf.value);
			if (!isValid) return;
			// 发起请求
			await apiVendingMachineShelves.put(`/${currentShelf.value.id}`, currentShelf.value);
			// 提交成功后的逻辑处理
			ElMessage.success('更新货架信息成功！');
			editDialogVisible.value = false; // 关闭对话框
			 fetchShelvesWithMedicineInfo();
		} catch (error) {
			console.error('Error submitting update:', error);
			ElMessage.error('更新货架信息失败，请重试！');
		}
	};

//-- ===================查询================================-->	
	 // 搜索货架的方法
	 const searchShelves = () => {
		// 检查查询字符串是否为空
		 if (searchParams.value.queryString.trim() === '') {
		   ElMessage.error('请输入数据');
		   return;
		 }
		 // 标记可以重置，因为用户已经输入了查询字符串
		 canReset.value = true; 
		 
	   // 检查查询字符串是否为纯数字
	   const queryId = String(searchParams.value.queryString).replace(/\D/g, '');
	   const isNumeric = queryId !== '' ;
	 
	   if (isNumeric) {
	     // 如果查询字符串是纯数字，则执行精准查询
	     shelves.value = orishelves.value.filter(shelf => {
	       const shelfId = shelf.id.toString();
	       return shelfId === queryId;
	     });
	   } else {
	     // 如果查询字符串包含非数字字符，则执行名称的包含查询
	     shelves.value = orishelves.value.filter(shelf => {
	       return shelf.medicine.name.toLowerCase().includes(searchParams.value.queryString.toLowerCase());
	     });
	   }
	 };
	
	// 重置搜索条件的方法
	const resetSearch = async () => {
		// 重新加载货架数据以刷新显示
		 fetchShelvesWithMedicineInfo();
		 canReset.value = false;
	 };	 

</script>

<style scoped>
	@import './all.css';
</style>
