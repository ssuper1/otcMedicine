<template>
	<div class="top">
		<div class="left">
			<el-button type="success" @click="showAddDialog = true">增加信息</el-button>
		</div>
		<!-- 搜索框 -->
		<div class="search-box">
			<el-input
				v-model="searchParams.queryString"
				placeholder="输入ID或姓名"
				class="search-input"
			></el-input>
			<el-button type="success" @click="performSearch">查询</el-button>
		</div>
	</div>
</template>