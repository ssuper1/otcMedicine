<template>	  
	<adminNavBar/>
<!-- ===================添加与搜索按钮================================-->	
	<div class="top">
		<div class="left">
			<el-button type="success" @click="showAddDialog = true">增加信息</el-button>
		</div>
		<!-- 搜索框 -->
		<div class="search-box">
			<el-input
				v-model="searchParams.queryString"
				placeholder="输入ID或名称/功能"
				class="search-input"
			></el-input>
			<el-button type="success" @click="performSearch">查询</el-button>
		</div>
	</div>

	
	  <!--========================= 增加的弹窗 =========================-->
	  <el-dialog v-model="showAddDialog"  title="增加药品信息"
	    width="40%" @closed="resetForm">
	    <!-- 表单 -->
	    <el-form :model="medicineForm" :rules="rules" ref="medicineFormRef" label-width="100px">
	        <el-form-item label="药品名称" prop="name">
	          <el-input v-model="medicineForm.name"></el-input>
	        </el-form-item>
	        <el-form-item label="价格" prop="price">
	          <el-input type="number" v-model="medicineForm.price"></el-input>
	        </el-form-item>
			<el-form-item label="种类" prop="kinds">
			  <el-input  v-model="medicineForm.kinds"></el-input>
			</el-form-item>
	        <el-form-item label="图片URL" prop="photoUrl">
	          <el-input v-model="medicineForm.photoUrl"></el-input>
	        </el-form-item>
	        <el-form-item label="生产日期" prop="productionDate">
	          <el-date-picker v-model="medicineForm.productionDate" type="date"></el-date-picker>
	        </el-form-item>
	        <el-form-item label="过期日期" prop="expirationDate">
	          <el-date-picker v-model="medicineForm.expirationDate" type="date"></el-date-picker>
	        </el-form-item>
	        <el-form-item label="详情描述" prop="description">
	          <el-input type="textarea" v-model="medicineForm.description"></el-input>
	        </el-form-item>
	        <el-form-item>
	          <el-button type="primary" @click="submitForm">提交</el-button>
	          <el-button @click="showAddDialog = false">取消</el-button>
	        </el-form-item>
	      </el-form>
	  </el-dialog>  
	  
	<!-- ====================================初始展示========================= -->  
	<!-- 表格 -->
	<div class="el-container">
  <el-table :data="pagedAccounts"  class="table" style="padding-left:10px ;">
    <el-table-column prop="id" label="ID" width="50"></el-table-column>
    <el-table-column prop="name" label="名称" width="120"></el-table-column>
	<el-table-column prop="kinds" label="种类" width="80"></el-table-column>
	<el-table-column prop="price" label="价格" width="80"></el-table-column>
    <el-table-column prop="photoUrl" label="图片" width="180">
      <template #default="{ row }">
        <!-- 使用 v-html 来生成 <img> 标签 -->
        <div v-html="createImageTag(row.photoUrl)"></div>
      </template>
    </el-table-column>
    <el-table-column prop="productionDate" label="生产日期" width="100"></el-table-column>
    <el-table-column prop="expirationDate" label="过期时间" width="100"></el-table-column>
    <el-table-column prop="description" label="详情"></el-table-column>
    <!-- 添加操作列 -->
    <el-table-column label="操作" width="200">
      <template #default="{ row }">
        <el-button type="primary" size="small" @click="editMedicine(row)">修改</el-button>
        <el-button type="danger" size="small" @click="deleteMedicine(row.id)">删除</el-button>
      </template>
    </el-table-column>
  </el-table>
  </div>
 <!--   <div id="main" style="width: 600px;height:400px;"></div> -->
			<!-- ==============分页=======================-->
		<el-pagination style="margin: 5px;display: flex; justify-content: center;"
			background layout="prev, pager, next ,jumper" 
 		  :current-page="currentPage"
 		  :page-size="pageSize"
 		  :total="medicines.length"
 		  @current-change="handleCurrentChange"></el-pagination>
  <!-- ===================修改弹窗================================-->
  <el-dialog
      v-model="editDialogVisible"
      title="编辑药品信息"
      width="40%">
      <el-form :model="currentMedicine">
        <!-- 这里添加表单项，绑定 currentMedicine 中的属性 -->
      <el-form-item label="药品名称">
        <el-input v-model="currentMedicine.name"></el-input>
      </el-form-item>
	  <el-form-item label="药品种类">
	    <el-input v-model="currentMedicine.kinds"></el-input>
	  </el-form-item>
      <el-form-item label="价格">
        <el-input type="number" v-model="currentMedicine.price"></el-input>
      </el-form-item>
      <el-form-item label="图片URL">
        <el-input v-model="currentMedicine.photoUrl"></el-input>
      </el-form-item>
      <el-form-item label="生产日期">
        <el-date-picker v-model="currentMedicine.productionDate" type="date"></el-date-picker>
      </el-form-item>
      <el-form-item label="过期日期">
        <el-date-picker v-model="currentMedicine.expirationDate" type="date"></el-date-picker>
      </el-form-item>
      <el-form-item label="详情描述">
        <el-input type="textarea" v-model="currentMedicine.description"></el-input>
      </el-form-item>
        <!-- ...其他表单项... -->
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button @click="editDialogVisible = false">取消</el-button>
          <el-button type="primary" @click="updateMedicine">更新</el-button>
        </div>
      </template>
    </el-dialog>
		
	<!-- “重置”按钮，仅在 canReset 为 true 时显示 -->
	    <el-button
	      type="warning"
	      v-if="canReset"
	      @click="resetSearch"
	      style="margin-left: 10px;">
	      返回
	    </el-button>	
			
</template>

<style scoped>
@import './all.css';
</style>


<script setup>
import { ref, onMounted,computed } from 'vue';
import { apiClient, apiVendingMachineShelves } from '../api';
import { ElForm, ElInput,ElButton,ElDialog, ElMessage } from 'element-plus';
import adminNavBar from './adminNav.vue'
/* import * as echarts from 'echarts';
// 表格数据
const tableData = ref([
  { kinds: '感冒类', count: 10 },
  { kinds: '肠胃类', count: 20 },
  { kinds: '外敷类', count: 5 }
]);	   
// 初始化图表
const initChart = () => {
  const chartDom = document.getElementById('main');
  const myChart = echarts.init(chartDom);
  const data = tableData.value.map(item => ({
    value: item.count,
    name: item.kinds
  }));
  const option = {
    series: [
      {
        type: 'pie',
        data: data
      }
    ]
  };
  myChart.setOption(option);
};	   
 */

	   
	const showAddDialog = ref(false);
	const searchParams = ref({ queryString: '' }); // 确保 searchParams 是一个 ref
	const medicineForm = ref({
	  name: '',       // 药品名称
	  price: '',      // 价格
	  photoUrl: '',   // 药品图片URL
	  productionDate: '',  // 生产日期
	  expirationDate: '',   // 过期日期
	  description: ''  // 详情描述
	});

	const canReset = ref(false);	
	const medicineFormRef = ref(null);
	// 校验规则
    const rules = {
      name: [{ required: true, message: '请输入药品名称', trigger: 'blur' },],
      kinds: [{ required: true, message: '请输入药品种类', trigger: 'blur' },],
	  price: [ { required: true, message: '请输入价格', trigger: 'blur' }, ],
      photoUrl: [{ required: true, message: '请输入图片URL', trigger: 'blur' },],
      productionDate: [{ required: true, message: '请选择生产日期', trigger: 'blur' }, ],
      expirationDate: [{ required: true, message: '请选择过期日期', trigger: 'blur' },],
      description: [{ required: false, message: '请输入详情描述', trigger: 'blur' },]
    };
	
	const resetForm = () => {
	  medicineForm.value = {
	   name: '',       // 药品名称
	   kinds:'',
	   price: '',      // 价格
	   photoUrl: '',   // 药品图片URL
	   productionDate: '',  // 生产日期
	   expirationDate: '',   // 过期日期
	   description: ''  // 详情描述
	  };
	  // 清除校验结果
	  medicineFormRef.value.clearValidate();
	};
// ===================展示================================-->		  
    const medicines = ref([]);//全部 {}单个
	const createImageTag = (photoUrl) => {
		return `<img src="${photoUrl}" alt="药品图片" style="width: 100px; height: auto;" />`;
		};
   onMounted(async () => {
	await fetchData();
	/* initChart(); */
   });
	//---------------------------------
	// 刷新表格数据
	const fetchData = async () => {
	  try {
	    const response = await apiClient.get('/');
	    medicines.value = response.data;//响应对象通常包含一个 data 属性
		
	  } catch (error) {
	    console.error('Error fetching medicines:', error);
	  }
	};	
//-- ===================分页===============================-->		
  const currentPage = ref(1);
   const pageSize = ref(4);
	const pagedAccounts = computed(() => {
	  const start = (currentPage.value - 1) * pageSize.value;
	  return medicines.value.slice(start, start + pageSize.value);
	});//当前页码的值 * 每页显示的条目数.第一页就从第a[0]条数据开始，到a[5]条
	
	const handleCurrentChange = (newPage) => {
	  currentPage.value = newPage; // 使用 .value 来直接操作响应式状态
	};
	
// ===================增================================-->		  
	const submitForm = async () => {
	  try {
		// 触发表单校验
		await medicineFormRef.value.validate();//rules就是定义的验证内容
		// 发起请求
		await apiClient.post('/', medicineForm.value);//apiClient里已经到了medicine了
		ElMessage.success('药品信息增加成功！');
		showAddDialog.value = false;
		resetForm();
		await fetchData();
	  } catch (error) {
		console.error('Error submitting form:', error);
		ElMessage.error('增加药品信息失败，请重试！');
	  }
	};
//-- ===================删除================================-->
    const deleteMedicine = async (id) => {
      try {
        await apiClient.delete(`/${id}`);
        // 刷新列表
        await fetchData();
      } catch (error) {
        console.error('Error deleting medicine:', error);
      }
    };	

// ===================改================================-->
    const editDialogVisible = ref(false); // 控制编辑对话框显示的响应式变量
    const currentMedicine = ref({}); // 当前编辑的药品信息
   
	const editMedicine = (row) => {
		// 显示编辑对话框并填充数据
		editDialogVisible.value = true;
		currentMedicine.value = { ...row };
	};  
	const updateMedicine = async () => {
	try {
	   await apiClient.put(`/${currentMedicine.value.id}`, currentMedicine.value);
	   ElMessage.success('更新药品信息成功！');
	   editDialogVisible.value = false; // 关闭对话框
	   // 刷新表格数据的逻辑
	   await fetchData();
	 } catch (error) {
	   console.error('Error updating row:', error);
	   ElMessage.error('更新药品信息失败！');
	 }
   };

//-- ===================查询================================-->	
  const performSearch = async () => {
        try {
          const queryString = searchParams.value.queryString.trim();
          if (queryString) {
			// 标记可以重置，因为用户已经输入了查询字符串
			canReset.value = true;
			const isNumeric = /^\d+$/.test(queryString);//\d数字		
			if (isNumeric){
				// 清除之前的值
				medicines.value = [];
				const response = await apiClient.get(`/${encodeURIComponent(queryString)}`);	 
				// 检查返回的数据是否存在
				const medicine = response.data;
				if (medicine) {
				  // 如果返回了药品数据，则将其设置为当前显示的药品列表
				  medicines.value.push(medicine);
				  ElMessage.success('查询成功！');						
				}	
			}
			// 发送请求到后端进行模糊查询，分别查询名称和描述
		   else{
            const [nameResponse, descriptionResponse] = await Promise.all([
              apiClient.get('/search', { params: { name: queryString } }),///search?name=queryString
              apiClient.get('/search', { params: { description: queryString } })
            ]);
            // 合并两个请求的结果，并去除重复项
            const allMedicines = [...new Set([...nameResponse.data, ...descriptionResponse.data])];
  
            // 更新药品列表
            medicines.value = allMedicines;
            ElMessage.success('查询成功！');
			}
          } else {
            ElMessage.error('请输入药品名称或描述进行搜索！');			
          }
        } catch (error) {
          ElMessage.error('查询失败，请稍后再试！');
          console.error('Error searching medicines:', error);
        }
      };
	// 重置搜索条件的方法
	const resetSearch = async () => {
		// 重新加载货架数据以刷新显示
		await fetchData();
		canReset.value = false;
	 };
	
   
</script>