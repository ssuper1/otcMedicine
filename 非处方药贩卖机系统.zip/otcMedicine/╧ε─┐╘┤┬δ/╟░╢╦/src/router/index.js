import { createRouter, createWebHashHistory } from 'vue-router'

const routes = [
  {
    path: '/medicineManage',
    name: 'medicineManage',
    component: () => import('../components/adminMedicineManage.vue')
  },
  {
    path: '/test',
    name: 'test',
    component: () => import( '../components/test.vue')
  },
  {
    path: '/vending-machine-shelves',
    name: 'vending-machine-shelves',	
    component: () => import( '../components/adminVendingMachineShelves.vue'),
	
  },
  {
    path: '/userBuy',
    name: 'userBuy',
    component: () => import('../components/userBuy.vue'),
  },
  {
    path: '/kinds',
    name: 'kinds',
    component: () => import('../components/kinds.vue'),
  },
  {
    path: '/zhu',
    name: 'zhu',
    component: () => import('../components/zhu.vue'),
  },
  {
    path: '/',
    name: 'userLogin',
    component: () => import( '../components/userLogin.vue')
  },
  {
    path: '/adminLogin',
    name: 'adminLogin',
    component: () => import( '../components/adminLogin.vue')
  }
  ,
  {
    path: '/introduce',
    name: 'introduce',
    component: () => import( '../components/userIntroduce.vue'),
  }
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router