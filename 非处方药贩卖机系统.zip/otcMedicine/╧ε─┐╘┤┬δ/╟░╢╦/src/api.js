import axios from 'axios';

const apiClient = axios.create({
  baseURL: 'http://localhost:8085/api/medicines', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const apiVendingMachineShelves = axios.create({
  baseURL: 'http://localhost:8085/api/vendingMachineShelves', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
const apiUserLogin = axios.create({
  baseURL: 'http://localhost:8085/api/auth', // 后端服务的URL
  timeout: 1000,
  headers: {'X-Requested-With': 'XMLHttpRequest'}
});
export { apiClient, apiVendingMachineShelves ,apiUserLogin};